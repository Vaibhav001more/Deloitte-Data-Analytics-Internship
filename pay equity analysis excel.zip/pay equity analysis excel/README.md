# pay-equity-analysis-excel

# Pay Equity Classification using Excel

This Excel-based analysis was completed as part of the Deloitte Virtual Internship on Forage. The objective was to classify employee compensation fairness across various job roles and factory locations.

## 🧰 Tools & Technologies
- Microsoft Excel
- IF and ABS formulas
- Logical classification

## 📝 Project Overview
An equality score (ranging from -100 to +100) was provided for each factory and job role. The task was to:

- Add a new column to classify each score as:
  - **Fair** (between -10 and +10)
  - **Unfair** (between -20 and -10 OR 10 and 20)
  - **Highly Discriminative** (beyond ±20)
  
- Use Excel formulas to automate classification logic.

## 📌 Sample Formula Used

```excel
=IF(ABS(C2)<=10,"Fair", IF(ABS(C2)<=20,"Unfair","Highly Discriminative"))
